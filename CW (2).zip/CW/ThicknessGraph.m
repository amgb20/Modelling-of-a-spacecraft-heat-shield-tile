% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function minimumThickness = ThicknessGraph(min,step,max)

tmax = 4000;
nt = 501;
nx = 21;
method = 'Crank-Nicolson'; %being the best method
enterTileNum = 5;
doPlot = false;
material = 'LI900';

xlim([0 4000])

i = 1;        

for thicktile = min:step:max
    hold on 
    
    % Call Shuttle function 
    [~, t, u] = shuttle(tmax, nt, thicktile, nx, method,enterTileNum,material, doPlot);
    
    % k is usefull for the legend to display the chosen thickness
    % it plots the different temperature behaviour in function of time for
    % different thickness.
    k(i) = plot(t,u(:,1));
    
    
    i=i+1;
end

%original temperature comparison
outerTemp=u(:,end);
k(end+1)= plot(t,outerTemp,'r--');
legend('0.01','0.03','0.05','0.07','0.09','0.11','0.13','0.15','outerTemp')

h = yline(450,'k--','MaxTemperature');
