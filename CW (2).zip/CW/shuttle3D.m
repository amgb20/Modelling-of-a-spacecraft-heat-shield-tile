function [x3, t3, u3, Uend] = shuttle3D(tmax3, nt3, xmax3, nx3, ymax3, ny3, zmax3, nz3, method, enterTileNum,material, doPlot)

% Function for modelling temperature in a space shuttle tile
% D N Johnston  05/02/21
%
% Input arguments:
% tmax   - maximum time
% nt     - number of timesteps
% xmax   - total thickness
% nx     - number of spatial steps
% method - solution method ('forward', 'backward' etc)
% doPlot - true to plot graph; false to suppress graph.
%
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix
%
% For example, to perform a  simulation with 501 time steps
%   [x, t, u] = shuttle(4000, 1001, 0.05, 21,0.05,81, 'Crank-Nicolson',5,'LI900', true);
%

% alpha is the Thermal Diffusivity of Materials (in mm2/s)
switch material
    case 'LI900'
        thermCon = 0.0577; % W/(m K)
        density  = 144;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in mm2/s)
        alpha = thermCon / (density * specHeat);

    case 'LI2200'
        thermCon = 0.0577; % W/(m K)
        density  = 352.4;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in m2/s)
        alpha = thermCon / (density * specHeat);
    case 'Aluminium'
        alpha = 9.7e-5;
    case 'Gold'
        alpha = 1.27e-4;
    case 'Silicon'        
        alpha = 8.8e-05;
    case 'Molybdenum'
        alpha = 54.3e-06;
    case 'Wood'
        alpha = 8.2e-08;
    case 'Iron'
        alpha = 2.3e-05;
    case 'Steel'
        alpha = 1.88e-05;
    case 'Inconel 600'
        alpha = 3.428e-06;
    case 'Quartz'
        alpha = 1.4e-06;
    case 'Glass'
        alpha = 3.4e-07;
    case 'Ice'
        alpha = 1.02e-07;
    case 'PVC'
        alpha = 8e-08;
    case 'Carbon Fiber'
        alpha = 2.165e-04;
    case 'Diamond'
        alpha = 3.06e-04;
    otherwise
        alpha = 1;
  
end


% loads data from graph image using image extraction function
[timeData,tempData] = ImgExtraction(enterTileNum);

% Initialise everything.
dt = tmax3 / (nt3-1); %time step size
dx = xmax3 / (nx3-1); %thickness step size
dy = ymax3 / (ny3-1); %tile width step size
dz = zmax3 / (nz3-1); 
x3 = (0:nx3-1) * dx; %thickness tile
y = (0:ny3-1) * dy;% tile width
z = (0:nz3-1) * dz;

islice = round((nx3-1)/2+1);
jslice = round((ny3-1)/2+1);
kslice = round((nz3-1)/2+1);


t3 = (0:nt3-1) * dt; % time vector
nt3 = length(t3);

u3 = zeros(nz3, ny3, nx3, nt3);

p = alpha * dt / dx^2;

sigma = 56.7e-9;
epsilon = 0.1;

    % Use interpolation to get outside temperature at times t 
    % and store it as right-hand boundary R.

    R = interp1(timeData, tempData, t3, 'linear', tempData(end));


% set initial conditions equal to boundary temperature at t=0.
u3(:, :, :, 1) = R(1);

%create a graph and show initial conditions. h is a 'handle' to the graph,
%for later use.
if doPlot == true
     
        
        figure(421);
       %create a graph and show initial conditions. 
        figure(1);
        % Plot slice at midpoint of z
        z0=zeros(ny3,nx3)+z(kslice);
        hz = surf(x3, y, z0, squeeze(u3(kslice,:,:,1)));
        hold on

        % Plot slice at midpoint of y
        yy = z*0+y(jslice); % y vector is of length z and is a constant.
        zy = z'*ones(size(x3)); 
        hy = surf(x3, yy, zy, squeeze(u3(:,jslice,:,1)));

        % Plot slice at midpoint of x
        xx = z*0+x3(islice);
        zx = ones(size(y))'*z; 
        hx = surf(xx, y, zx, squeeze(u3(:,:,islice,1))');
        shading('interp')

        pbaspect([xmax3 ymax3 zmax3])

        % set z axis range
        zlim([0 zmax3])

        % set colour map range
        caxis ([0 1500]);
        colorbar

        %display the current time
        h2=text(-0.05, 0.1, 0, ' t = 0 s   ', 'BackgroundColor', [1,1,1]);

        % set labels. Note: \it gives italics, \rm gives normal text.
        xlabel('\itx\rm - m')
        ylabel('\ity\rm - m')
        zlabel('\itz\rm - m')

else
    error
end

for n = 1:nt3-1

    % Select method.
    switch method
       
        case 'Forward-Differencing'
            % set up index vectors
            i  = 2:nx3-1;
            im = 1:nx3-2;
            ip = 3:nx3;
            j  = 2:ny3-1;
            jm = 1:ny3-2;
            jp = 3:ny3;
            k  = 2:nz3-1;
            km = 1:nz3-2;
            kp = 3:nz3;

            % calculate internal values using forward differencing
                u3(k, j, i, n+1) = (1 - 6 * p) * u3(k, j, i, n) + ...
                    p * (u3(k, j, im, n) + u3(k, j, ip, n) + ...
                    u3(k, jm, i, n) + u3(k, jp, i, n) +...
                    u3(km, j, i, n) + u3(kp, j, i, n));
                
%                 u3(1, j, i, n+1) = (1 - 6 * p) * u3(1, j, i, n) + ...
%                     p * (u3(1, j, im, n) + u3(1, j, ip, n) + ...
%                     u3(1, jm, i, n) + u3(1, jp, i, n) +...
%                     u3(km, j, i, n) + u3(kp, j, i, n));

            %Robin boundaries 
            
            % heat flow at west boundary (qw is a vector)
            qw = sigma * epsilon * (1573^4 - (u3(k,j,1,n)+273).^4);
            % add heat flow term to boundary temperature
            u3(k,j,1,n+1) = u3(k,j,1,n+1) + 2 * qw * dx * p / thermCon;

            % heat flow at north boundary
            qn = sigma * epsilon * ((u3(nz3,ny3,i,n)+273).^4 - 1573^4);
            % add heat flow term to boundary temperature
            u3(nz3,ny3,i,n+1) = u3(nz3,ny3,i,n+1) - 2 * qn * dy * p / thermCon;

            case 'Dufort-Frankel'
            % Boundary condition from outside temperature
            u3(:,:,nx3,n+1) = R(n+1);
            
            % set up index vectors
            i  = 2:nx3-1;
            im = 1:nx3-2;
            ip = 3:nx3;
            j  = 2:ny3-1;
            jm = 1:ny3-2;
            jp = 3:ny3;
            k  = 2:nz3-1;
            km = 1:nz3-2;
            kp = 3:nz3;

            % calculates U state vector with respect to thickness and width of the tile
            % calculate internal values using forward differencing
            u3(k,j, i, n+1) = ((1 - 6 * p) * u3(k,j, i, n) + ...
                p * (u3(k,j, im, n) + u3(k,j, ip, n) + u3(k,jm, i, n) + u3(k,jp, i, n))) / (1+6*p);  
            
            u3(1,j, i, n+1) = ((1 - 6 * p) * u3(1,j, i, n) + ...
            p * (u3(1,j, im, n) + u3(1,j, ip, n) + 2*u3(2,j, i, n))) / (1+6*p);
            
        otherwise
            error (['Undefined method: ' method])
            return
            
    end
    
       % update graph with new values
    set(hz,'CData', squeeze(u3(kslice, :, :, n+1)));
    set(hy,'CData', squeeze(u3(:, jslice, :, n+1)));
    set(hx,'CData', squeeze(u3(:, :, islice, n+1))');
    
    %display current time
    txt = sprintf(' t = %4.1f s ', t3(n+1));
    set(h2, 'String', txt)
    % and refresh it on screen
    drawnow
end

% and a 2D plot of centre temperature against time
figure (3)
% 'squeeze' removes redundant dimensions of the 3D u array
ucentre = squeeze(u3(kslice, jslice, islice, :));
plot(t3, ucentre, 'r')
xlabel('\itt\rm - s');
ylabel('\itu\rm - deg C');
title('Centre temperature - 2D model')

% show where 1100C is reached.
i450 = find((ucentre >= 450),1);
if ~isempty(i450)
    hold all
    plot(t3(i450), 450, 'o')
    text(t3(i450), 450, ['Time to reach 1100\circC = ' num2str(t(i450)) 's \rightarrow  '],...
        'HorizontalAlignment', 'right'); 
    hold off
end