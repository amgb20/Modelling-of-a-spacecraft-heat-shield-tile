% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [x, t, u] = shuttle(tmax, nt, xmax, nx, method, enterTileNum, material, doPlot)
% Function for modelling temperature in a space shuttle tile
% D N Johnston  05/02/21
%
% Input arguments:
% tmax   - maximum time
% nt     - number of timesteps
% xmax   - total thickness
% nx     - number of spatial steps
% method - solution method ('forward', 'backward' etc)
% doPlot - true to plot graph; false to suppress graph.
%
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix
%
% For example, to perform a  simulation with 501 time steps
%   [x, t, u] = shuttle(4000, 501, 0.05, 21, 'forward',enterTileNum,LI900, true);
%

% alpha is the Thermal Diffusivity of Materials (in mm2/s)
switch material
    case 'LI900'
        thermCon = 0.0577; % W/(m K)
        density  = 144;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in mm2/s)
        alpha = thermCon / (density * specHeat);

    case 'LI2200'
        thermCon = 0.0577; % W/(m K)
        density  = 352.4;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in m2/s)
        alpha = thermCon / (density * specHeat);
    case 'Aluminium'
        alpha = 9.7e-5;
    case 'Gold'
        alpha = 1.27e-4;
    case 'Silicon'        
        alpha = 8.8e-05;
    case 'Molybdenum'
        alpha = 54.3e-06;
    case 'Wood'
        alpha = 8.2e-08;
    case 'Iron'
        alpha = 2.3e-05;
    case 'Steel'
        alpha = 1.88e-05;
    case 'Inconel 600'
        alpha = 3.428e-06;
    case 'Quartz'
        alpha = 1.4e-06;
    case 'Glass'
        alpha = 3.4e-07;
    case 'Ice'
        alpha = 1.02e-07;
    case 'PVC'
        alpha = 8e-08;
    case 'Carbon Fiber'
        alpha = 2.165e-04;
    case 'Diamond'
        alpha = 3.06e-04;
    otherwise
        alpha = 1;
  
end

[timeData,tempData] = ImgExtraction(enterTileNum);

% Initialise everything.
dt = tmax / (nt-1);
t = (0:nt-1) * dt;
dx = xmax / (nx-1);
x = (0:nx-1) * dx;
u = zeros(nt, nx);


p = alpha * dt / dx^2;

    % set initial conditions equal to boundary temperature at t=0.
    u([1 2],:) = 289.15; % Assumption of initial temeprature on the inside of the tile, check units
    
    ivec = 2:nx-1; % set up index vector

% Main timestepping loop.
for n = 2:nt - 1
    
    % Use interpolation to get outside temperature at times t 
    % and store it as right-hand boundary R.
    R = interp1(timeData, tempData, t(n+1), 'linear','extrap');
    
    u(n+1,nx) = R; % Defining the temperature on the outer side of the tile
    % Select method.
    switch method
        case 'Forward-Differencing'
            
            % Neumann Boundary (inner side of the tile)
            u(n+1,1) = (1 - 2 * p) * u(n,1) + 2*p * u(n,2);
            
%             % Robin Boundary 
%             % adjust boundary values using radiation equation. Note that we must use temperature in K.
%             q1 = sigma * emissivity * ((tfurnace+273)^4 - (u(n,1)+273)^4);
%             u(n+1,1) = u(n+1,1) + 2 * p * dx * q1 / thermCon;
% 
%             qnx = sigma * emissivity * ((u(n,nx)+273)^4-(tfurnace+273)^4);
%             u(n+1,nx) = u(n+1,nx) - 2 * p * dx * qnx / thermCon;
            
            % Intermediate points of the tile
            u(n+1,ivec) = (1 - 2 * p) * u(n,ivec) + p * (u(n,ivec-1) + u(n,ivec+1)); 
            
        case 'Dufort-Frankel'
            
            % Neumann Boundary (inner side of the tile)
            u(n+1,1) = ((1-2*p)*u(n-1,1)+4*p*u(n,2))/(1+2*p);    
            
            % Intermediate points of the tile
            u(n+1,ivec) = ((1-2*p)*u(n-1,ivec) + 2*p*(u(n,ivec-1)+u(n,ivec+1)))/(1+2*p);
                    
        case 'Backward Differencing'
           
           % left boundary
           b(1) = 1 + 2*p; 
           c(1) = -2*p; 
           d(1) = u(n,1); 
           
           % internal points
           a(ivec) = -p; 
           b(ivec) = 1 + 2*p; 
           c(ivec) = -p; 
           d(ivec) = u(n,ivec); 
           
           % right boundary
           a(nx) = 0; 
           b(nx) = 1; 
           d(nx) = R; 
           u(n+1,:) = tdm(a,b,c,d); 
            
        case 'Crank-Nicolson'
            b(1) = 1 + p; 
            c(1) = -p; 
            d(1) = (1-p)*u(n,1) + p*u(n,2); 
            a(ivec) = -p/2; 
            b(ivec) = 1 + p; 
            c(ivec) = -p/2; 
            d(ivec) = p/2 * u(n,1:nx-2) + (1-p)*u(n,2:nx-1) + (p/2)*u(n,3:nx); 
            a(nx) = 0; 
            b(nx) = 1; 
            d(nx) = R; 
            u(n+1,:) = tdm(a,b,c,d);
            
           otherwise
            error (['Undefined method: ' method])
            return
    end
end

if doPlot
    % Create a plot here.
    
    figure(2)
    % contour plot
    surf(x,t,u)
    % comment out the next line to change the surface appearance
    shading interp
    
    % Rotate the view
    view(140,30)
    
    %label the axes
    xlabel('\itx\rm - m')
    ylabel('\itt\rm - s')
    zlabel('\itu\rm - deg K')
    title('Forward Differencing')    

end



    