% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function x = tdm(a,b,c,d)
% tdm: Tri-diagonal matrix solution used to solve Backward and Crank-Nicolson methods

n = length(b); 
% Eliminate a terms 
for i = 2:n 
    ratio = a(i) / b(i-1); 
    b(i) = b(i) - ratio * c(i-1); 
    d(i) = d(i) - ratio * d(i-1); 
end

x(n) = d(n)/b(n);

% back-substitution and loop back
for i = n-1:-1:1 
    x(i) = (d(i) - c(i)*x(i+1)) / b(i); 
end