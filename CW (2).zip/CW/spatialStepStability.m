% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [nx,dx,ucn] = spatialStepStability(enterTileNum) 

% This script investigates the stability for the number of spatial steps
% nx when we use the best method which is Crank-Nicolson.
%
% Input:
% The input will be determined by the enterTileNum that the user is going 
% to choose in the ImgExtraction script.
% 
% Output
%
% nt: maximum number of time steps 
% nx: maximum number of spatial steps 
% dx: maximum spatial step 
% uck: inner surface temperature at time = 4000 sec against the timestep
% for Crank Nicolson

% Variables:
% 
% i: initial conditions
% thick: thickness of the tile
% tmax: temperature maximal

% Initial Conditions 
i=0; 
nt = 621; 
thick = 0.05; 
tmax = 4000; 
material = 'LI900';

for nx = 2:35 
    i=i+1; 
    dx(i) = thick / (nx-1); 
    tic
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Forward-Differencing',enterTileNum,material, false);
    time1('Forward-Differencing',i) = toc;
    uf(i) = u(end, 1);
    tic
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Backward Differencing',enterTileNum,material, false);
    time2('Backward Differencing',i) = toc;
    ub(i) = u(end, 1);
    tic
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Dufort-Frankel',enterTileNum,material, false);
    time3('Dufort-Frankel',i) = toc;
    ud(i) = u(end, 1);
    tic
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Crank-Nicolson',enterTileNum,material, false);
    time4('Crank-Nicolson',i) = toc;
    ucn(i) = u(end, 1); 
end

% Knowing that the best method is Crank-Nicolson, we are already taking
% into consideration that nx will rely on this method as well.
%
% We are trying to find the suitable number of spatial steps.

% Finds the optimal number of spatial steps with a percentage error of 1% 
posCN = min(find( ucn > 0.99.*ucn(end))); 
StableDX = dx(posCN); 
nx = ((thick/StableDX)+1);

figure(7)
plot(dx, [time1;time2;time3;time4])
% ylim([0 400])
legend ('Crank-Nicolson','Backward Differencing','Dufort-Frankel','Forward-Differencing')
xlabel('dx')
ylabel('time taken (s)')

figure(99)
plot(dx, [uf;ud;ucn;ub])
legend ('Crank-Nicolson','Backward Differencing','Dufort-Frankel','Forward-Differencing')
ylim([300 500])
ylabel('T K')
xlabel('dx')