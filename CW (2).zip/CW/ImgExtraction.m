% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [timeData,tempData] = ImgExtraction(enterTileNum)
% ImgExtraction scans and plots the tile image chosen by the user.
%
% Image from http://www.columbiassacrifice.com/techdocs/techreprts/AIAA_2001-0352.pdf
% Now available at 
% http://citeseerx.ist.psu.\edu/viewdoc/download?doi=10.1.1.26.1075&rep=rep1&type=pdf
%
% The user will input a number between 1 and 8 to choose which graph he
% wants to plot
% 
% This program will give two outputs: timeData (time x-axis) and tempData (temperature in Kelvin y-axis) according to
% the graph chosen by the user.

extractingTileImages = ["temp468.jpg","temp480.jpg","temp502.jpg","temp590.jpg", "temp597.jpg","temp711.jpg","temp730.jpg","temp850.jpg"];

% reads the chosen image
img = imread(extractingTileImages(enterTileNum)); 

% matrice storing the size of the image
[rows columns numColours] = size(img); 

% Matrice storing red pixels by sibstracting bleu and green pixels
redPix = img(:,:,1) - img(:,:,2) - img(:,:,3); 

% Matrice storing black pixels
blackPix = img(:,:,1) + img(:,:,2) + img(:,:,3);

% Finds the y and x axis 
vertAxis = find(sum(blackPix) == min(sum(blackPix))); 
horAxis = find(sum(blackPix,2) == min(sum(blackPix,2))); 

% Axis end  
horEnd = max(find(blackPix(horAxis,:) ~= 255)); 
vertEnd = horAxis - max(diff(find(blackPix(:,vertAxis) == 255))); 

% Axis length 
vertLength = horAxis - vertEnd; 
horizonLength = horEnd - vertAxis; 

% Finds the function's middle red pixel in each pixel column of the image  
for column = 1:columns 
    
    tempData(column) = median(find(redPix(:,column) > 160)); 
    
end

% Scales the coordinates of the red pixels found 
tempData = horAxis-tempData;

for column = 1:columns 
    
    if find(isnan(tempData(column))) 
        
        tempData(column) = 0; 
        
    end
end

tempData(find(tempData == 0)) = [];

timeData = 1:length(tempData); 

tempData = (tempData * 2000)/vertLength; 

timeData = (timeData * 2000)/horizonLength; 

% Converts temperature values to kelvin.
tempData = (tempData +459.67) * (5/9);

% This line smooths the extrapolation in R for the shuttle program. 
tempData(end) = tempData(end-1);

% sort data and remove duplicate points.
[timeData, index] = unique(timeData);
tempData = tempData(index);


% figure (17)
% plot(timeData,tempData)
% xlabel('Time(s)') 
% ylabel('Temperature(K)')
% 
% hold off

