

% Script to plot image of measured temperature, and trace it using the mouse.
%
% Image from http://www.columbiassacrifice.com/techdocs/techreprts/AIAA_2001-0352.pdf
% Now available at 
% http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.26.1075&rep=rep1&type=pdf
%
% D N Johnston 05/02/21

name = 'temp597';
img=imread([name '.jpg']);

figure (4);
image(img);
hold on
% You can adapt the following code to enter data interactively or automatically.

[j,i] = find(img(:,:,1)>150 & img(:,:,2)<100 & img(:,:,3) <100);
[iu, iindex] = unique(i);
[iul, iindexl] = unique(i, 'last');
ju = j(iindex);
juL = j(iindexl);

jComb = (ju + juL)./2;


figure (5);
% plot(i,j,'x');
% hold on
% plot(iu,ju);
% hold on
% plot(iu,juL);
% hold on
% plot(iu,jComb)
% xlabel('Time(s)') 
% ylabel('Temperature(F)')


% allows the graph to rotate by 180 degrees
set(gca,'Ydir','reverse')

% Conversion from arbitrary pixel values to true parameter units
timeData = (iu-50)/(max(iu)-50)*2000;           % Seconds
tempData = -(jComb-max(jComb))/(94)*2000;       % Farenheit
tempData = (tempData+459.67)*(5/9);             % Converting to Kelvin

plot(timeData,tempData)
xlabel('Time(s)') 
ylabel('Temperature(K)')

hold off

% sort data and remove duplicate points.
[timeData, index] = unique(timeData);
tempData = tempData(index);

%save data to .mat file with same name as image file
save(name, 'timeData', 'tempData')

