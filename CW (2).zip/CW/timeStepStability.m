% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [dt, nt, uf, ub, ud, ucn, BM] = timeStepStability(enterTileNum)

% This script investigate the stability and accuracy of the
% Forward-differencing, Dufort-Frankel, Backward-differencing and
% Crank-Nicolson methods for a range of values of timestep.
%
% For each method, this plots the inner surface temperature at time = 4000 sec
% against the timestep.
%
% Input:
% The input will be determined by the enterTileNum that the user is going 
% to choose in the ImgExtraction script.
%
% Output:
% 
% dt: max time step
% nt: maximum number of time steps 
% uf: inner surface temperature at time = 4000 sec against the timestep
% for Forward differencing

% ub: inner surface temperature at time = 4000 sec against the timestep
% for Backward differencing

% ud: inner surface temperature at time = 4000 sec against the timestep
% for Dufort Frankel

% uck: inner surface temperature at time = 4000 sec against the timestep
% for Crank Nicolson
%
% BM: stands for the best methods
%
% Variables:
% 
% i: initial conditions
% nx: number of spatial steps
% thick: thickness of the tile
% tmax: temperature maximal

i=0;
nx = 21;
thick = 0.05;
tmax = 4000;
material = 'LI900';

% this code is provided by Dr Nigel Johnstone
for nt = 41:20:1001
    i=i+1;
    dt(i) = tmax/(nt-1);
    disp (['nt = ' num2str(nt) ', dt = ' num2str(dt(i)) ' s'])
    tic % starts timer
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Forward-Differencing', enterTileNum,material, false); %calls shuttle to output the temperature
    time1('Forward-Differencing',i) = toc; % stores time taken for each step size
    uf(i) = u(end, 1);
    tic % starts timer
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Backward Differencing',enterTileNum,material, false);
    time2('Backward Differencing',i) = toc; % stores time taken for each step size
    ub(i) = u(end, 1);
    tic % starts timer
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Dufort-Frankel',enterTileNum,material, false);
    time3('Dufort-Frankel',i) = toc; % stores time taken for each step size
    ud(i) = u(end, 1);
    tic % starts timer
    [~, ~, u] = shuttle(tmax, nt, thick, nx, 'Crank-Nicolson',enterTileNum,material, false);
    time4('Crank-Nicolson',i) = toc; % stores time taken for each step size
    ucn(i) = u(end, 1);
end

% In order to find the most suitable timestep and accurate method, we need
% to find the sum of the absolute of the gradient of each methods.
% The function gradient returns the numerical gradient of uf, ud, ub or
% ucn.
%
% The goal is to find the minimum sum of gradient for each methods which
% will constitute the best method.

ufGdtSum = sum(abs(gradient(uf)));
udGdtSum = sum(abs(gradient(ud)));
ubGdtSum = sum(abs(gradient(ub)));
ucnGdtSum = sum(abs(gradient(ucn)));

totalGdtSum = [ufGdtSum,udGdtSum,ubGdtSum,ucnGdtSum];


methods = ["Forward-Differencing", "Backward Differencing", "Dufort-Frankel", "Crank-Nicolson"]; 
BM = methods(find(totalGdtSum == min(totalGdtSum))); 

% Crank-Nicolson being the most accurate method is used to find the optimal 
% number of time steps

if BM == 'Crank-Nicolson'
     posCN = find(abs(gradient(ucn)) == min(abs(gradient(ucn)))); 
     StableDT = dt(posCN); 
     nt = round((tmax/StableDT) + 1);
     
elseif BM == 'Forward-Differencing'
     posFD = find(abs(gradient(uf)) == min(abs(gradient(uf)))); 
     StableDT = dt(posFD); 
     nt = round((tmax/StableDT) + 1);

elseif BM == 'Dufort-Frankel'
     posDF = find(abs(gradient(ud)) == min(abs(gradient(ud)))); 
     StableDT = dt(posDF); 
     nt = round((tmax/StableDT) + 1);
     
elseif BM == 'Backward Differencing'
     posBD = find(abs(gradient(ub)) == min(abs(gradient(ub)))); 
     StableDT = dt(posBD); 
     nt = round((tmax/StableDT) + 1);
end

figure(20)
plot(dt, [ucn;ub;ud;uf])
ylim([300 400])
legend ('Crank-Nicolson','Backward Differencing','Dufort-Frankel','Forward-Differencing')
ylabel('T K')
xlabel('dt')

figure(21)
plot(dt, [time1; time2; time3; time4])
legend ('Crank-Nicolson','Backward Differencing','Dufort-Frankel','Forward-Differencing')
xlabel('dt')
ylabel('time taken (s)')