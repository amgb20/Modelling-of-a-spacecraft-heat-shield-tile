% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [x1,y, t1, u1, Uend] = shuttle2DV2(tmax1, nt1, xmax1, nx1, ymax1, ny1, method, enterTileNum,material, doPlot)

% Function for modelling temperature in a space shuttle tile
% D N Johnston  05/02/21
%
% Input arguments:
% tmax   - maximum time
% nt     - number of timesteps
% xmax   - total thickness
% nx     - number of spatial steps
% method - solution method ('forward', 'backward' etc)
% doPlot - true to plot graph; false to suppress graph.
%
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix
%
% For example, to perform a  simulation with 501 time steps
%   [x, t, u] = shuttle(4000, 1001, 0.05, 21,0.05,81, 'Crank-Nicolson',5,'LI900', true);
%

% alpha is the Thermal Diffusivity of Materials (in mm2/s)
switch material
    case 'LI900'
        thermCon = 0.0577; % W/(m K)
        density  = 144;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in mm2/s)
        alpha = thermCon / (density * specHeat);

    case 'LI2200'
        thermCon = 0.0577; % W/(m K)
        density  = 352.4;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in m2/s)
        alpha = thermCon / (density * specHeat);
    case 'Aluminium'
        alpha = 9.7e-5;
    case 'Gold'
        alpha = 1.27e-4;
    case 'Silicon'        
        alpha = 8.8e-05;
    case 'Molybdenum'
        alpha = 54.3e-06;
    case 'Wood'
        alpha = 8.2e-08;
    case 'Iron'
        alpha = 2.3e-05;
    case 'Steel'
        alpha = 1.88e-05;
    case 'Inconel 600'
        alpha = 3.428e-06;
    case 'Quartz'
        alpha = 1.4e-06;
    case 'Glass'
        alpha = 3.4e-07;
    case 'Ice'
        alpha = 1.02e-07;
    case 'PVC'
        alpha = 8e-08;
    case 'Carbon Fiber'
        alpha = 2.165e-04;
    case 'Diamond'
        alpha = 3.06e-04;
    otherwise
        alpha = 1;
  
end


% loads data from graph image using image extraction function
[timeData,tempData] = ImgExtraction(enterTileNum);

% Initialise everything.
dt = tmax1 / (nt1-1); %time step size
dx = xmax1 / (nx1-1); %thickness step size
dy = ymax1 / (ny1-1); %tile width step size
x1 = (0:nx1-1) * dx; %thickness tile
y = (0:ny1-1) * dy;% tile width

t1 = (0:nt1-1) * dt; % time vector
nt1 = length(t1);

u1 = zeros(ny1, nx1, nt1);

p = alpha * dt / dx^2;

sigma = 56.7e-9;
epsilon = 0.1;

    % Use interpolation to get outside temperature at times t 
    % and store it as right-hand boundary R.

    R = interp1(timeData, tempData, t1, 'linear', tempData(end));


% set initial conditions equal to boundary temperature at t=0.
u1(:, :, 1) = R(1);

%create a graph and show initial conditions. h is a 'handle' to the graph,
%for later use.
if doPlot == true
     
        
        figure(420);
        h1 = surf(x1, y, u1(:,:,1)); 
        
        pbaspect([1 4 1]) 
        
        %displays the current time of animation
        h2=text(-0.05, 0.18, 280, ' t = 0 s   ', 'BackgroundColor', [1,1,1]);
        
        shading interp 

        % set y axis range
        zlim([-0 1500])
        % set colour map range
        caxis ([0 1500]);
        colorbar
        
        % set axes labels
        xlabel('\itx\rm (m)')
        ylabel('\ity\rm (m)')
        zlabel(['\itu\rm Kelvin (K)'])

else
    error
end


for n = 1:nt1-1

    % Select method.
    switch method
       
        case 'Forward-Differencing'
            % Boundary condition from outside temperature
            u1(:,nx1,n+1) = R(n+1);
            
            % Neuman Boundaries set up index vectors
            i = 1:nx1-1;
            im = [2 1:nx1-2];
            ip = 2:nx1;

            j = 2:ny1;
            jm = 1:ny1-1;
            jp = [3:ny1 ny1-1];

            % calculates U state vector with respect to thickness and width of the tile
            % calculate internal values using forward differencing
            u1(j, i, n+1) = (1 - 4 * p) * u1(j, i, n) + ...
                p * (u1(j, im, n) + u1(j, ip, n) + u1(jm, i, n) + u1(jp, i, n));

            
            u1(1, i, n+1) = (1 - 4 * p) * u1(1, i, n) + ...
                p * (u1(1, im, n) + u1(1, ip, n) + 2*u1(2, i, n));
            
            %Robin boundaries 
            
            % heat flow at west boundary (qw is a vector)
            qw = sigma * epsilon * (1573^4 - (u1(j,1,n)+273).^4);
            % add heat flow term to boundary temperature
            u1(j,1,n+1) = u1(j,1,n+1) + 2 * qw * dx * p / thermCon;

            % heat flow at north boundary
            qn = sigma * epsilon * ((u1(ny1,i,n)+273).^4 - 1573^4);
            % add heat flow term to boundary temperature
            u1(ny1,i,n+1) = u1(ny1,i,n+1) - 2 * qn * dy * p / thermCon;
            
            case 'Dufort-Frankel'
            % Boundary condition from outside temperature
            u1(:,nx1,n+1) = R(n+1);
            
            % Neuman Boundaries set up index vectors
            i = 1:nx1-1;
            im = [2 1:nx1-2];
            ip = 2:nx1;

            j = 2:ny1;
            jm = 1:ny1-1;
            jp = [3:ny1 ny1-1];

            % calculates U state vector with respect to thickness and width of the tile
            % calculate internal values using forward differencing
            u1(j, i, n+1) = ((1 - 4 * p) * u1(j, i, n) + ...
                p * (u1(j, im, n) + u1(j, ip, n) + u1(jm, i, n) + u1(jp, i, n))) / (1+4*p);  
            
            u1(1, i, n+1) = ((1 - 4 * p) * u1(1, i, n) + ...
            p * (u1(1, im, n) + u1(1, ip, n) + 2*u1(2, i, n))) / (1+4*p);
            
       
        case 'Backward Differencing'
            
            % GAUSS METHOD
            
            maxiterations = 100; % timestep
            tolerance = 1.e-4; % for stability
            % Boundary condition from outside temperature
            u1(:,nx1,:) = R(n+1);
            % calculate internal values iteratively using Gauss-Seidel
            % Starting values are equal to old values
            u1(:, :, n+1) = u1(:, :, n);
            
            % iteration loop
            for iteration = 1:maxiterations
                change = 0;
                
                %calculate new internal values
                for i=2:nx1-1
                    
                    for j=2:ny1-1
                        uold = u1(j, i, n+1); % store old value so we can check change
                        u1(j, i, n+1) = ((u1(j, i, n) + p * (u1(j-1, i, n+1) + u1(j+1, i, n+1)...
                            + u1(j, i-1, n+1) + u1(j, i+1, n+1)))/(1+4*p));
                        
                        change = change + abs(u1(j, i, n+1) - uold);
                    end
                end
                % exit backward method calculations if unstable
                if change < tolerance
                    break
                end
            end
            %disp(['Time = ' num2str(t(n)) ' s: Iterations = ' num2str(iteration)]);
            
            case 'Crank-Nicolson'
            
            maxiterations = 100; % timestep
            tolerance = 1.e-4; % for stability
            % Boundary condition from outside temperature
            u1(:,nx1,:) = R(n+1);
            % calculate internal values iteratively using Gauss-Seidel
            % Starting values are equal to old values
            u1(:, :, n+1) = u1(:, :, n);
            
            % iteration loop
            for iteration = 1:maxiterations
                change = 0;
                
                %calculate new internal values
                for i=2:nx1-1
                    
                    for j=2:ny1-1
                        uold = u1(j, i, n+1); % store old value so we can check change
                        u1(j, i, n+1) = ((u1(j, i, n)*(1-2*p) + (p/2) * (u1(j-1, i, n+1) + u1(j+1, i, n+1)...
                            + u1(j, i-1, n+1) + u1(j, i+1, n+1) + u1(j-1, i, n) + u1(j+1, i, n)...
                            + u1(j, i-1, n) + u1(j, i+1, n)))/(1+2*p));
                        
                        change = change + abs(u1(j, i, n+1) - uold);   
                    end
                end
            end
                
        otherwise
            error (['Undefined method: ' method])
            return
    end
    % update graph with new values
    set(h1,'ZData', u1(:, :, n+1));
            
    % display current time
    txt = sprintf(' t = %4.1f s ', t1(n+1));
    set(h2, 'String', txt)
    % Refresh screen
    drawnow
end

Uend = u1(end);


% and a 2D plot of centre temperature against time
figure (700)
% 'squeeze' removes redundant dimensions of the 3D u array
ucentre = squeeze(u1((ny1+1)/2, (nx1+1)/2, :));
plot(t1, ucentre, 'r')
xlabel('\itt\rm - s');
ylabel('\itu\rm - Kelvin K');
title('Centre temperature - 2D model')

% show where 450K is reached.
i450 = find((ucentre >= 450),1);
if ~isempty(i450)
    hold all
    plot(t1(i450), 450, 'o')
    text(t1(i450), 450, ['Time to reach 450\circC = ' num2str(t1(i450)) 's \rightarrow  '],...
        'HorizontalAlignment', 'right'); 
    hold off
end


    