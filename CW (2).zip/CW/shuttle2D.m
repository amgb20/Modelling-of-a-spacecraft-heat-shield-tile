% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [x,t,u] = shuttle2D(tmax, nt, xmax, nx, ymax, ny, method, enterTileNum,material, doPlot)

% Function for modelling temperature in a space shuttle tile
% D N Johnston  05/02/21
%
% Input arguments:
% tmax   - maximum time
% nt     - number of timesteps
% xmax   - total thickness
% nx     - number of spatial steps
% method - solution method ('forward', 'backward' etc)
% doPlot - true to plot graph; false to suppress graph.
%
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix
%
% For example, to perform a  simulation with 501 time steps
%   [x, t, u] = shuttle(4000, 1001, 0.05, 21,0.05,81, 'Crank-Nicolson',5,'LI900', true);
%

% alpha is the Thermal Diffusivity of Materials (in mm2/s)
switch material
    case 'LI900'
        thermCon = 0.0577; % W/(m K)
        density  = 144;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in mm2/s)
        alpha = thermCon / (density * specHeat);

    case 'LI2200'
        thermCon = 0.0577; % W/(m K)
        density  = 352.4;   % 9 lb/ft^3
        specHeat = 1261;  % ~0.3 Btu/lb/F at 500F
        
        %Thermal Diffusivity of Materials (in m2/s)
        alpha = thermCon / (density * specHeat);
    case 'Aluminium'
        alpha = 9.7e-5;
    case 'Gold'
        alpha = 1.27e-4;
    case 'Silicon'        
        alpha = 8.8e-05;
    case 'Molybdenum'
        alpha = 54.3e-06;
    case 'Wood'
        alpha = 8.2e-08;
    case 'Iron'
        alpha = 2.3e-05;
    case 'Steel'
        alpha = 1.88e-05;
    case 'Inconel 600'
        alpha = 3.428e-06;
    case 'Quartz'
        alpha = 1.4e-06;
    case 'Glass'
        alpha = 3.4e-07;
    case 'Ice'
        alpha = 1.02e-07;
    case 'PVC'
        alpha = 8e-08;
    case 'Carbon Fiber'
        alpha = 2.165e-04;
    case 'Diamond'
        alpha = 3.06e-04;
    otherwise
        alpha = 1;
  
end

% % Set tile properties
% thermCon = 0.0577; % W/(m K)
% density  = 144;   % 9 lb/ft^3
% specHeat = 1261;  % ~0.3 Btu/lb/F at 500F

% Better to load surface temperature data from file.
% (you need to have modified and run plottemp.m to create the file first.)
% Uncomment the following line.
% load temp597.mat

[timeData,tempData] = ImgExtraction(enterTileNum);

% Initialise everything.
dt = tmax / (nt-1); %time step size
dx = xmax / (nx-1); %thickness step size
dy = ymax / (ny-1); %tile width step size
x = (0:nx-1) * dx; %thickness tile
y = (0:ny-1) * dy;% tile width

t = (0:nt-1) * dt; % time vector
nt = length(t);

u = zeros(ny, nx, nt);

% alpha = thermCon ./ (density * specHeat);

p = alpha * dt / dx^2;
% sigma = 56.7e-9;
% epsilon = 0.1;

R = interp1(timeData, tempData, t, 'linear',tempData(end));

%set initial conditions equal to boundary temperature at t=0.
u(:, :, 1) = R(1);

%create a graph and show initial conditions. h is a 'handle' to the graph,
%for later use.
figure(1);
h1 = surf(x, y, u(:,:,1));
%view(2)
pbaspect([1 4 1])

%display the current time
h2=text(-0.05, 0.1, 0, ' t = 0 s   ', 'BackgroundColor', [1,1,1]);

shading interp
% set y axis range
zlim([-0 2000])
% set colour map range
caxis ([0 2000]);
colorbar

% set labels. Note: \it gives italics, \rm gives normal text.
xlabel('\itx\rm - m')
ylabel('\ity\rm - m')
zlabel('\itu\rm - deg C')


% Main timestepping loop.
for n = 1:nt - 1
        
    switch method
        case 'Forward-Differencing'
            % Boundary condition from outside temperature
            u(:,nx,n+1) = R;
            
            % set up index vectors
            i  = 1:nx-1;
            im = [2 1:nx-2];
            ip = 2:nx; 

            j  = 2:ny;
            jm = 1:ny-1;
            jp = [3:ny ny-1];
            
            % calculate internal values using forward differencing
            u(j, i, n+1) = (1 - 4 * p) * u(j, i, n) + ...
                p * (u(j, im, n) + u(j, ip, n) + u(jm, i, n) + u(jp, i, n));

            
            u(1, i, n+1) = (1 - 4 * p) * u(1, i, n) + ...
                p * (u(1, im, n) + u(1, ip, n) + 2*u(2, i, n));

            % update graph with new values
            set(h1,'ZData', u(:, :, n+1));

            %display current time
            txt = sprintf(' t = %4.1f s ', t(n+1));
            set(h2, 'String', txt)
            % and refresh it on screen
            drawnow
            
        case 'Backward Differencing'
            maxiterations = 100; % timestep
            tolerance = 1.e-4; % for stability
            % Boundary condition from outside temperature
%             u(:,nx,:) = R(n+1);
            % calculate internal values iteratively using Gauss-Seidel
            % Starting values are equal to old values
            u(:, :, n+1) = u(:, :, n);

            for iteration = 1:maxiterations
                change = 0;
                for i=2:nx-1
                    for j=2:ny-1
                        uold = u(j, i, n+1);
                        u(j, i, n+1) = ((u(j, i, n) + p * (u(j-1, i, n+1) + u(j+1, i, n+1)...
                            + u(j, i-1, n+1) + u(j, i+1, n+1)))/(1+4*p));
                        change = change + abs(u(j, i, n+1) - uold);
                    end
                end
                % exit backward method calculations if unstable
                if change < tolerance
                    break
                end
            end
                        % update graph with new values
            set(h1,'ZData', u(:, :, n+1));

            %display current time
            txt = sprintf(' t = %4.1f s ', t(n+1));
            set(h2, 'String', txt)
            % and refresh it on screen
            drawnow
            
            otherwise
            error (['Undefined method: ' method])
            return
    end
end
    
% and a 2D plot of centre temperature against time
figure (3)
% 'squeeze' removes redundant dimensions of the 3D u array
ucentre = squeeze(u((ny+1)/2, (nx+1)/2, :));
plot(t, ucentre, 'r')
xlabel('\itt\rm - s');
ylabel('\itu\rm - deg C');
title('Centre temperature - 2D model')

% show where 450K is reached.
i450 = find((ucentre >= 1100),1);
if ~isempty(i450)
    hold all
    plot(t(i450), 450, 'o')
    text(t(i450), 450, ['Time to reach 1100\circC = ' num2str(t(i450)) 's \rightarrow  '],...
        'HorizontalAlignment', 'right'); 
    hold off
end
    