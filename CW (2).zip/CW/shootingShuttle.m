% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [thick, error,times] = shootingShuttle(desiredTemp, desiredTempError,enterTileNum)

% Shotting method (learn during the firt term) allows us to find the
% accurate thickness regarding a desired internal temperature.

% Input arguments:
% desiredTemp: internal tiles's temperature (K)
% desiredTempError: error (C)
% enterTileNum: a number between 1-8

% Output arguments:
% thick: minimum required tile thickness
% error: error between desired temp and actual temp

% Variables
tmax = 4000;
nt = 501;
nx = 21;
method = 'Crank-Nicolson';
material = 'LI900';

tic 

thick(1) = 0.01;     % 1 thickness guess (m)
thick(2) = 0.015;    % 2 thickness guess (m)

E = desiredTempError - 274.15;       % initiates e so that it is larger than desiredTempError
n = 1;              % initial loop count

while desiredTempError < abs(E)
    if n > 2
        thick(n) = thick(n-1) - E(n-1)*(thick(n-1)-thick(n-2))/(E(n-1)-E(n-2));
    end
    
    [~,~,u] = shuttle(tmax, nt, thick(n), nx, method,enterTileNum, material,false);
    
    E(n) = max(u(:,1)) - desiredTemp; % error actual internal temp versus target temp
    
    n = n + 1;  % steps the loop count
end

times = toc;
thick = thick(end);
error = E(end);

end

