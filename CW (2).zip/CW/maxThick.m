% Modelling Technique 2, Course Work: Spacecraft heat shield tile
% Author : Dr Johnston and Mr Alexandre BENOIT

function [thick] = maxThick(enterTileNum) 

% calculates the optimal thickness
% 
% Input Argument:

% entertileNum - The tile to be analysed 
% 
% Output Argument: 
% thick - The minimal thickness a tile can be 
% Initial Conditions i=0; 
% nt = timeStepStability(enterTileNum);
% nx = spatialStepStability(enterTileNum);

nt = 941;
nx = 4; 
tmax = 4000; 
i=0;
material = 'LI900';

% Finds the tile's inner surface temperature at t=4s for varying thickness 
% for the Crank-Nicolson method 
for thick = 0.05:0.01:0.2 
    i=i+1; 
    [~, ~, u] = shuttle(tmax, nt, thick, nx,'Crank-Nicolson',enterTileNum,material, true); 
    uEndMax(i) = max(u(:,1)); 
end
% Finds the minimal thickness of the concerned tile 
thickVec = 0.05:0.01:0.2; 
thick = thickVec(min(find(uEndMax < 450))); %max temperature aluminium